cse2050_LiamDumbell_final_project
compile with: 'python3 main.py' in terminal