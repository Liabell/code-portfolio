from main_window import open_main_window
open_main_window() # opens the central widget / main window